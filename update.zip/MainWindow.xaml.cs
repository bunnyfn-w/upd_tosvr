using System.IO;
using System.Windows;
using System.Windows.Input;
using Microsoft.Win32;
using System.Net.Http;
using System.Text.Json;
using System.IO.Compression;

// Add hozzá ezt a metódust a MainWindow konstruktorhoz vagy egy külön gombhoz / indítási ponthoz:
private async Task CheckForUpdatesAsync()
{
    try
    {
        string jsonUrl = "https://raw.githubusercontent.com/FELHASZNALONEV/PROJEKTNEV/main/version.json";
        
        using HttpClient client = new HttpClient();
        string jsonResponse = await client.GetStringAsync(jsonUrl);

        using JsonDocument doc = JsonDocument.Parse(jsonResponse);
        JsonElement root = doc.RootElement;

        string latestVersion = root.GetProperty("Version").GetString()!;
        string downloadUrl = root.GetProperty("DownloadUrl").GetString()!;

        // Jelenlegi verzió (ezt állítsd be a saját projektverziódra)
        string currentVersion = "1.0.0"; 

        if (latestVersion != currentVersion)
        {
            MessageBox.Show($"Új frissítés érhető el ({latestVersion})! A letöltés elindul a háttérben.", "Frissítés", MessageBoxButton.OK, MessageBoxImage.Information);
            
            string updateFolder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "updates");
            Directory.CreateDirectory(updateFolder);
            string zipPath = Path.Combine(updateFolder, "update.zip");

            // Update letöltése
            byte[] fileBytes = await client.GetByteArrayAsync(downloadUrl);
            await File.WriteAllBytesAsync(zipPath, fileBytes);

            // Kicsomagolás
            ZipFile.ExtractToDirectory(zipPath, updateFolder, true);

            MessageBox.Show("A frissítés sikeresen letöltődött és kibontásra került!", "Kész", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }
    catch (Exception ex)
    {
        // Ha nincs net vagy hiba van, ne álljon meg a launcher, csak lépjen tovább
        System.Diagnostics.Debug.WriteLine("Frissítési hiba: " + ex.Message);
    }
}

namespace MtaLauncher
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            AutoDetectMta();
            AutoDetectGta();
        }

        // Ablak mozdítása egérrel
        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ButtonState == MouseButtonState.Pressed)
            {
                DragMove();
            }
        }

        // Minimalizálás
        private void MinimizeButton_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }

        // Bezárás
        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        // Navigáció: Csatlakozás
        private void NavConnect_Click(object sender, RoutedEventArgs e)
        {
            ConnectPanel.Visibility = Visibility.Visible;
            NewsPanel.Visibility = Visibility.Collapsed;
            StatsPanel.Visibility = Visibility.Collapsed;
            SettingsPanel.Visibility = Visibility.Collapsed;
        }

        // Navigáció: Hírek
        private void NavNews_Click(object sender, RoutedEventArgs e)
        {
            ConnectPanel.Visibility = Visibility.Collapsed;
            NewsPanel.Visibility = Visibility.Visible;
            StatsPanel.Visibility = Visibility.Collapsed;
            SettingsPanel.Visibility = Visibility.Collapsed;
        }

        // Navigáció: Statisztika
        private void NavStats_Click(object sender, RoutedEventArgs e)
        {
            ConnectPanel.Visibility = Visibility.Collapsed;
            NewsPanel.Visibility = Visibility.Collapsed;
            StatsPanel.Visibility = Visibility.Visible;
            SettingsPanel.Visibility = Visibility.Collapsed;
        }

        // Navigáció: Beállítások
        private void NavSettings_Click(object sender, RoutedEventArgs e)
        {
            ConnectPanel.Visibility = Visibility.Collapsed;
            NewsPanel.Visibility = Visibility.Collapsed;
            StatsPanel.Visibility = Visibility.Collapsed;
            SettingsPanel.Visibility = Visibility.Visible;
        }

        // Automatikus MTA keresés a gépen
        private void AutoDetectMta()
        {
            string foundExe = FindMtaExecutable();
            if (!string.IsNullOrEmpty(foundExe))
            {
                TxtClientPath.Text = Path.GetDirectoryName(foundExe);
            }
        }

        private string FindMtaExecutable()
        {
            string[] standardPaths = {
                @"C:\Program Files (x86)\MTA San Andreas 1.6\Multi Theft Auto.exe",
                @"C:\Program Files\MTA San Andreas 1.6\Multi Theft Auto.exe",
                @"D:\MTA San Andreas 1.6\Multi Theft Auto.exe",
                @"E:\MTA San Andreas 1.6\Multi Theft Auto.exe"
            };

            foreach (var path in standardPaths)
            {
                if (File.Exists(path))
                {
                    return path;
                }
            }

            try
            {
                using (var key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\WOW6432Node\Multi Theft Auto: San Andreas") ??
                                 Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Multi Theft Auto: San Andreas"))
                {
                    if (key != null)
                    {
                        object? installPath = key.GetValue("InstallPath") ?? key.GetValue("Last Install Location");
                        if (installPath != null)
                        {
                            string exePath = Path.Combine(installPath.ToString()!, "Multi Theft Auto.exe");
                            if (File.Exists(exePath))
                            {
                                return exePath;
                            }
                        }
                    }
                }
            }
            catch { }

            return string.Empty;
        }

        // Automatikus GTA SA keresés a gépen
        private void AutoDetectGta()
        {
            string foundExe = FindGtaExecutable();
            if (!string.IsNullOrEmpty(foundExe))
            {
                TxtGtaPath.Text = Path.GetDirectoryName(foundExe);
            }
        }

        private string FindGtaExecutable()
        {
            string[] standardPaths = {
                @"C:\Program Files (x86)\Rockstar Games\GTA San Andreas\gta-sa.exe",
                @"C:\Program Files\Rockstar Games\GTA San Andreas\gta-sa.exe",
                @"C:\Games\GTA San Andreas\gta-sa.exe",
                @"C:\GTA San Andreas\gta-sa.exe",
                @"D:\Games\GTA San Andreas\gta-sa.exe",
                @"D:\GTA San Andreas\gta-sa.exe",
                @"C:\Program Files (x86)\Steam\steamapps\common\Grand Theft Auto San Andreas\gta-sa.exe",
                @"C:\Program Files\Steam\steamapps\common\Grand Theft Auto San Andreas\gta-sa.exe"
            };

            foreach (var path in standardPaths)
            {
                if (File.Exists(path))
                {
                    return path;
                }
            }

            try
            {
                using (var key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\WOW6432Node\Rockstar Games\GTA San Andreas\1.00.0000") ??
                                 Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Rockstar Games\GTA San Andreas"))
                {
                    if (key != null)
                    {
                        object? installPath = key.GetValue("Path");
                        if (installPath != null)
                        {
                            string exePath = Path.Combine(installPath.ToString()!, "gta-sa.exe");
                            if (File.Exists(exePath))
                            {
                                return exePath;
                            }
                        }
                    }
                }
            }
            catch { }

            return string.Empty;
        }

        // Játék indítása gomb - Közvetlen szerver csatlakozással
        private void PlayButton_Click(object sender, RoutedEventArgs e)
        {
            string serverIpAndPort = "mtasa://45.146.6.53:22003"; // <-- Ide írd be a szerver IP-jét és portját!

            string mtaPath = FindMtaExecutable();

            if (string.IsNullOrEmpty(mtaPath) && !string.IsNullOrEmpty(TxtClientPath.Text))
            {
                string customPath = Path.Combine(TxtClientPath.Text, "Multi Theft Auto.exe");
                if (File.Exists(customPath))
                {
                    mtaPath = customPath;
                }
            }

            if (string.IsNullOrEmpty(mtaPath) || !File.Exists(mtaPath))
            {
                MessageBox.Show("Nem sikerült automatikusan megtalálni az MTA-t a gépen! Kérlek, add meg a Beállítások fülön kézzel.", "Hiányzó MTA", MessageBoxButton.OK, MessageBoxImage.Warning);
                NavSettings_Click(sender, e);
                return;
            }

            try
            {
                System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
                {
                    FileName = mtaPath,
                    Arguments = serverIpAndPort,
                    UseShellExecute = true
                });
            }
            catch (System.Exception ex)
            {
                MessageBox.Show($"Hiba történt az MTA indítása közben: {ex.Message}", "Hiba", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // GTA San Andreas mappa tallózása
        private void BrowseGtaButton_Click(object sender, RoutedEventArgs e)
        {
            var openFileDialog = new OpenFileDialog
            {
                Title = "Válaszd ki a gta-sa.exe fájlt",
                Filter = "GTA Executable (gta-sa.exe)|gta-sa.exe"
            };

            if (openFileDialog.ShowDialog() == true)
            {
                string folderPath = Path.GetDirectoryName(openFileDialog.FileName) ?? "";
                TxtGtaPath.Text = folderPath;
            }
        }

        // MTA mappa tallózása
        private void BrowseClientButton_Click(object sender, RoutedEventArgs e)
        {
            var openFileDialog = new OpenFileDialog
            {
                Title = "Válaszd ki az MTA.exe fájlt",
                Filter = "MTA Executable (*.exe)|*.exe"
            };

            if (openFileDialog.ShowDialog() == true)
            {
                string folderPath = Path.GetDirectoryName(openFileDialog.FileName) ?? "";
                TxtClientPath.Text = folderPath;
            }
        }

        // Cache törlése gomb
        private void DeleteClientFiles_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("A kliens gyorsítótár kiürítve!", "Karbantartás", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }
}