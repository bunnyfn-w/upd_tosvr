using System.Windows;

namespace MtaLauncher
{
    public partial class App : Application
    {
    }
}